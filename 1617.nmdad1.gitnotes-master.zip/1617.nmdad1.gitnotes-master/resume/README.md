#Curriculum Vitae
![alt tag](http://i.imgur.com/lEuBKAg.jpg)


----------


 >**Kevin Tresinie**  <br>
 >Student  <br>
> Sint-Jozefsstraat 6,  <br>
> 3690 Zutendaal  <br>
> 29/07/1993  <br>
> Man  <br>
> Belg  <br>
> Facebook: https://www.facebook.com/kevin.tresinie  <br>


------

### Opleiding
> Artevelde hogeschool - Grafische en Digitale Media


------
### Werkervaring

> Vakantiejob: Ford Genk (bandwerk)


------

### Computerkennis

> 1. JavaScript/Jquerry
> 1. PhP
> 1. HTML
> 1. CSS
> 1. Premiere
> 1. After Effects
> 1. Indesign


----------

### Talenkennis
> Nederlands
> Engels

------
###Contact
> kevin.tresinie@student.arteveldehs.be  <br>
> 0498/79 81 05