#Curriculum Vitae
[<img src="imgur.com/kuTmg"](http://imgur.com/)
 >Kevin Tresinie
 ## Student
> Sint-Jozefsstraat 6,3690 Zutendaal
> 29/07/1993
> Man
> Belg
> Vrijgezel
------
> [kevin.tresinie@student.arteveldehs.be]
> 0498798105

------

### Computerkennis

1. JavaScript
1. Premiere
1. After Effects
1. Indesign

------


### Opleiding

**Artevelde hogeschool grafische digitale media**

### Talenkennis
> Nederlands
> Engels